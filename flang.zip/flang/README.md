# E-Comerce desenvolvido para o PAC

#Objetivo:
Criar uma aplicação web estilo E-Comerce conectado com banco de dados.
