<div class="container">
    <h3 class=title-Cadastro>
        Recupere a sua senha!
    </h3>
    <br>

    <form action="#" method="post">
        <div class="Formulario">
            <p> Informe o e-mail</p>
            <label for="email"> <i class="fas fa-envelope-square icon-modify"></i> Email: </label> <br>
            <input type="text" class="inputs" name="email" id="email"> <br>
            <input type="submit">
        </div>


    </form>

</div>